import { Pool, type PoolClient } from "pg";
import { env } from "../../config/env";

export type Queryable = Pick<Pool | PoolClient, "query">;

export const pool = new Pool({
  connectionString: env.databaseUrl
});

export async function withTransaction<T>(fn: (client: PoolClient) => Promise<T>): Promise<T> {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const result = await fn(client);
    await client.query("COMMIT");
    return result;
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

export async function closePool(): Promise<void> {
  await pool.end();
}
